# README #

A pure pursuit path following controller, implemented in ROS.

## Dependencies ##

Installable with rosdep:
```
rosdep install pure_pursuit
```


## Usage ##

To se a demo of the controller in action, use the [lattice_navigation_demos package](https://github.com/larics/lattice_navigation_demos).

## Limitations ##

The controller currently does not handle backwards driving correctly.
